package com.example.reelfinder

import android.app.*
import android.os.Bundle
import android.content.Intent
import android.graphics.BitmapFactory
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

class MainActivity: AppCompatActivity() {
    private lateinit var result: TextView
    private val pickCode = 42

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36,50,36,30)
        }
        val title = TextView(this).apply {
            text = "Instagram Reel Finder"
            textSize = 28f
        }
        val info = TextView(this).apply {
            text = "Paste a public Reel link, or upload a screenshot if the username isn't available from the link."
            textSize = 16f
            setPadding(0,20,0,20)
        }
        val link = EditText(this).apply {
            hint = "https://www.instagram.com/reel/..."
        }
        val find = Button(this).apply { text = "Find account from link" }
        val upload = Button(this).apply { text = "Upload screenshot" }
        result = TextView(this).apply {
            textSize = 18f
            setPadding(0,25,0,0)
        }

        find.setOnClickListener {
            val s = link.text.toString().trim()
            result.text = if (s.contains("instagram.com/reel/"))
                "Reel link detected.\n\nDirect username lookup needs an authorized Instagram/API source. This prototype does not bypass Instagram restrictions.\n\nTry Upload screenshot to detect a visible @username."
            else "Please paste a valid Instagram Reel link."
        }

        upload.setOnClickListener {
            startActivityForResult(
                Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    type = "image/*"
                    addCategory(Intent.CATEGORY_OPENABLE)
                }, pickCode
            )
        }

        box.addView(title)
        box.addView(info)
        box.addView(link)
        box.addView(find)
        box.addView(upload)
        box.addView(result)
        setContentView(box)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != pickCode || resultCode != RESULT_OK || data?.data == null) return

        try {
            val uri = data.data!!
            contentResolver.openInputStream(uri).use { stream ->
                val bmp = BitmapFactory.decodeStream(stream)
                val image = InputImage.fromBitmap(bmp, 0)
                TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                    .process(image)
                    .addOnSuccessListener { vision ->
                        val hits = Regex("@[A-Za-z0-9._]+")
                            .findAll(vision.text)
                            .map { it.value }
                            .distinct()
                            .toList()

                        result.text = if (hits.isNotEmpty())
                            "Possible account(s):\n" + hits.joinToString("\n")
                        else
                            "No visible @username detected. Try a clearer screenshot showing the Reel username."
                    }
                    .addOnFailureListener {
                        result.text = "OCR failed: ${it.message}"
                    }
            }
        } catch (e: Exception) {
            result.text = "Could not read image: ${e.message}"
        }
    }
}

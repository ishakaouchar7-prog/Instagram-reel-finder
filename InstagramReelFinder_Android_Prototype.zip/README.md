# Instagram Reel Finder — Android prototype

Paste an Instagram Reel URL or upload a screenshot. The prototype validates the URL and uses Google ML Kit OCR to detect visible @usernames. It does not bypass Instagram access controls.
